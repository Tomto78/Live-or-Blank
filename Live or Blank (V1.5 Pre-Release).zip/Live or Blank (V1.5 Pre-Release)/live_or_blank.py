# [Imports]
# ====================================================================================================
import random
import time
import math
# ====================================================================================================


# [Colour variables]
# ====================================================================================================
RESET = "\033[0m" # ANSI color codes for a better UI
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
PURPLE = "\033[95m"
BOLD = "\033[1m"
BLUE = "\033[94m"
WHITE = "\033[97m"

TIER_COLOURS = {
    1: "\033[32m",  # Green for Tier 1
    2: "\033[34m",  # Blue for Tier 2
    3: "\033[33m",  # Yellow for Tier 3
    4: "\033[35m",  # Purple for Tier 4
    5: "\033[31m"   # Red for Tier 5
}
# ====================================================================================================


# [Data]
# ====================================================================================================
items = [
    # Tier 1
    {"name": "🩹 Bandage", 
     "tier": 1, "id": 0, 
     "description": "Restores 1 health."},
    
    {"name": "📱 Phone", 
     "tier": 1, "id": 1, 
     "description": "Reveals the type of one random bullet in the magazine."},
    
    {"name": "🔎 Magnifying Glass", 
     "tier": 1, "id": 2, 
     "description": "Reveals the type of the current bullet in the magazine."},
    
    {"name": "💵 Money", 
     "tier": 1, "id": 3, 
     "description": "Bribe the gamemaster, eject the current bullet from the magazine."},
    
    {"name": "🔁 Uno Reverse Card", 
     "tier": 1, "id": 4, 
     "description": "Inverts the bullet type of the current bullet."},
    
    {"name": "🍀 Four-Leaf Clover", 
     "tier": 1, "id": 5, 
     "description": ""},
    
    {"name": "🚬 Cigarette", 
     "tier": 1, "id": 6, 
     "description": ""},

    # Tier 2
    {"name": "🦺 Kevlar Vest", 
     "tier": 2, "id": 7, 
     "description": "Protects the user from 1 point of damage.",
     "active": False},
    
    {"name": "🔥 Fire Extinguisher", 
     "tier": 2, "id": 8, 
     "description": ""},
    
    {"name": "🌿 Herbs", 
     "tier": 2, "id": 9, 
     "description": ""},
    
    {"name": "🍷 Wine", 
     "tier": 2, "id": 10, 
     "description": ""},
    
    # Tier 3
    {"name": "❤️  Medkit", 
     "tier": 3, "id": 11, 
     "description": "Restores 2 health and removes any illness effects."},
    
    {"name": "👓 X-ray Goggles", 
     "tier": 3, "id": 12, 
     "description": "Provides information of 3 random bullets in the magazine (use when magazine > 2)"},
    
    {"name": "🔮 Small Crystal Ball", 
     "tier": 3, "id": 13, 
     "description": "Searches for a bullet type, returns the position of the first target bullet type found"},
    
    {"name": "🛡️  Iron Shield", 
     "tier": 3, "id": 14, 
     "description": ""},
    
    {"name": "⚠️  Suspicious Substance", 
     "tier": 3, "id": 15, 
     "description": "Who knows what this does... an even chance of a positive and negative outcome"},
    
    # Tier 4
    {"name": "🎰 Slot Machine", 
     "tier": 4, "id": 16, 
     "description": ""},
    
    {"name": "⛽ Petrol", 
     "tier": 4, "id": 17, 
     "description": ""},
    
    {"name": "🔮 Large Crystal Ball", 
     "tier": 4, "id": 18, 
     "description": ""},
    
    {"name": "📖 Book of Fortune", 
     "tier": 4, "id": 19, 
     "description": ""},
    
    # Tier 5
    {"name": "⚡ Faulty Defibrillator", 
     "tier": 5, "id": 20, 
     "description": ""},
    
    {"name": "🎁 Mystery Box", 
     "tier": 5, "id": 21, 
     "description": "Receive 5 random items."},

    {"name": "🧪 Magic Potion", 
     "tier": 5, "id": 22, 
     "description": ""}
]

# ====================================================================================================


# [Creating objects containing necessary variables]
# ====================================================================================================
class UserStats:
    """Creating users (E.g. Player and Bot)"""

    def __init__(self):
        self.health = 0 
        self.inventory = [0] * len(items)
        self.active_items = [False] * len(items)

    # Updating the health of the user
    def update_health(self, amount: int):
        self.health += amount

    # Updating the quantity of items in the inventory
    def update_inventory(self, item_id: int, amount: int):
        self.inventory[item_id] += amount 
    
    # Updating whether an item is active or not
    def update_active_items(self, item_id: int, state: bool):
        self.active_items[item_id] = state

    # Reset all attributes to their starting values
    def reset(self):
        self.__init__()

class GameStateDefault:
    """Creating an object containing all default values of specified variables"""

    def __init__(self):
        self.default_bullet_probability = [45, 45, 10] # Live, Blank, Special
        self.default_mag_max_size = [3, 10] # Range
        self.default_item_give_player_amount = [2, 7] # Range
        self.default_item_give_bot_amount = [2, 5] # Range
        self.default_item_probability = [45, 29, 18, 9, 4] # Rarity of items from tiers 1-5 
        self.default_item_ban_list = [5, 6, 8, 9, 10, 14, 16, 17, 18, 19, 20, 22] # ID of items that are banned
        
        # Values which determines the bot's decision making
        self.default_bot_confidence = 0.4 
        self.default_risk_threshold = 0.0

class AdminSettings:
    """Creating an object containing the custom values of specified variables"""

    def __init__(self):
        self.item_probability = [0, 0, 0, 60, 40]
        self.item_give_player_amount = [20, 30]
        self.item_give_bot_amount = [5, 10]
        self.bullet_probability = [0, 0, 100]
        self.mag_max_size = [10, 25]
        self.player_health = 10
        self.bot_health = 15

class GameStateCurrent:
    """Creating an object containing the current values of specified variables (to track game state)"""

    def __init__(self):
        self.gamemode = None # Current gamemode
        self.difficulty = None # Current difficulty

        self.round = 0 # Current round
        self.turn = 0 # Current turn

        self.bullet_probability = GameStateDefault().default_bullet_probability # Spawn chance of bullets
        self.mag = [] # Current magazine
        self.mag_max_size = GameStateDefault().default_mag_max_size # The set range for the size of the magazine
        self.mag_shot_history = [] # A list of previously shot bullets for the current round

        self.item_give_player_amount = GameStateDefault().default_item_give_player_amount # Range 
        self.item_give_bot_amount = GameStateDefault().default_item_give_bot_amount # Range
        self.item_probability = GameStateDefault().default_item_probability # Current rarity of items from tiers 1-5
        self.item_ban_list = GameStateDefault().default_item_ban_list # ID of items that are banned

        self.bot_confidence = GameStateDefault().default_bot_confidence
        self.risk_threshold = GameStateDefault().default_risk_threshold

    # Update variables to admin 
    def apply_admin(self):
        self.bullet_probability = AdminSettings().bullet_probability
        self.mag_max_size = AdminSettings().mag_max_size
        self.item_give_player_amount = AdminSettings().item_give_player_amount
        self.item_give_bot_amount = AdminSettings().item_give_bot_amount
        self.item_probability = AdminSettings().item_probability

    def reset(self):
        self.__init__()

class GameStats:
    """Creating an object containing statistics of the game being played"""

    def __init__(self):

        self.total_rounds = 0
        self.total_turns = 0

        self.total_bullets_shot = 0

        self.total_health_lost = 0
        self.player_health_lost = 0
        self.bot_health_lost = 0

        self.total_items_used = 0
        self.player_items_used = 0
        self.bot_items_used = 0

    def reset(self):
        self.__init__()
    
class Permissions:
    """Creating an object containing the gamerules"""

    def __init__(self):
        self.is_player_turn = True
        self.allow_item_spawn = None
        self.allow_item_ban = None
        self.allow_item_use = True
    
    def reset(self):
        self.__init__()

player = UserStats()
bot = UserStats()
permissions = Permissions()
admin = AdminSettings()
game_state = GameStateCurrent()
game_stats = GameStats()
# ====================================================================================================


# [Functions]
# ====================================================================================================
def introduction():
    """Displays the game introduction and initial instructions to the player."""

    print(f"{WHITE}={RESET}" * 50)
    print(f"{BOLD}{CYAN}WELCOME TO{RESET}".center(60))
    print(f"{BOLD}{WHITE}⚔️  LIVE OR BLANK: THE ULTIMATE GAMBLE  ⚔️{RESET}".center(60))
    
    print(f"{WHITE}={RESET}" * 50 + "\n")
    print((

        f"{BOLD}{YELLOW}📜 HOW TO PLAY:{RESET}\n"

        f"{YELLOW}1.{RESET} The gun will be loaded with X bullets (LIVE or BLANK).\n"
        f"{YELLOW}2.{RESET} You can either shoot your opponent or yourself.\n"
        f"{YELLOW}3.{RESET} If you fire a blank at yourself, you get another turn.\n"
        f"{YELLOW}4.{RESET} Turns swap after each shot.\n"
    ))
    print(f"{WHITE}={RESET}" * 50 + "\n")

    print((
        f"{BOLD}{WHITE}V1.5{RESET} - By {RED}Tomato78{RESET}\n\n"

        f"{BOLD}{WHITE}CHANGES IN THIS VERSION:{RESET}\n"
        f"Rewrote the script for better back-end system\n"
        f"{BOLD}- GAMEPLAY{RESET}\n"
        f"  - New Item: Kevlar Vest [Tier 2] (Protects the user from 1 point of damage. Breaks after one use.)\n"
        f"  - New Item: X-ray Goggles [Tier 3] (Provides information on 3 random bullets in the magazine.)\n"
        f"  - New Item: Mystery Box [Tier 5] (Receive 5 random items.)\n"
        f"  - New Item: Suspicious Substance [Tier 3] (Has an equal chance of a positive or negative effect when used.)\n"
        f"  - New Item: Small Crystal Ball [Tier 3] (Reveals the position of the first bullet of a chosen type in the magazine.)\n"
        f"  - Rarity of item tiers will vary based on difficulty\n\n"
        
        f"{BOLD}- BOT UPDATE{RESET}\n"
        f"  - New 'Risk' and 'Confidence value"
        f"  - Risk: Affected by the probability of live bullets, using binomial distribution to calculate"
        f"  - Confidence: Events such as getting hit or missing will lower and increase confidence"
        f"  - Bot will now have various playstyles, which are affected through risk and confidence levels"
        f"  - Bot has been updated with additional response to different actions"
        f"  - \n\n"
        
        f"{BOLD}- OTHER{RESET}\n"
        f"  - Fixed Suspicious Substance's quantity not being reduced after usage\n"
        f"  - Fixed items spawning inside quickplay\n"
        f"  - Fixed X-ray Goggles not working when there's 3 bullets left\n"
        f"  - Fixed Small Crystal Ball not providing the right information\n"
        f"  - Changed default spawn chance of different tiers of items [45, 29, 18, 9, 4]\n"
        f"  - Changed Expert difficulty on Classic mode to give the bot 15 health instead of 10\n"
        f"  - Changed using items will now use the item's ID instead of name\n"
    ))
    print(f"{WHITE}={RESET}" * 50 + "\n")

def input_start():
    """Allows the player to start the game or enter settings"""

    while True:

        select_options = input(f"Type {WHITE}START{RESET} to begin: ").lower()

        match(select_options):
            case "start":
                return
            case "settings" | "setting" | "options" | "set":
                print("Not yet implemented")
    
def input_gamemode():
    """Allows the player to select a gamemode (e.g. Quickplay, Classic)."""
    
    while game_state.gamemode == None:
        print("\n" + f"{WHITE}-{RESET}" * 50)
        select_gamemode = input(f"{BOLD}{WHITE}Choose gamemode{RESET} (Quickplay, Classic): ").lower().capitalize()
        print(f"{WHITE}-{RESET}" * 50)

        match(select_gamemode):
            case "Quickplay" | "Classic" | "Admin":
                game_state.gamemode = select_gamemode
                if select_gamemode == "Quickplay":
                    permissions.allow_item_spawn = False
                    permissions.allow_item_use = False
                    permissions.allow_item_ban = False
                else:
                    permissions.allow_item_spawn = True
                    permissions.allow_item_use = True
                    permissions.allow_item_ban = True

def input_difficulty():
    """Lets the player set the game's difficulty level, affecting various mechanics."""
    match(game_state.gamemode):
        
        case "Quickplay":
            
            while game_state.difficulty == None:
                print("\n" + f"{WHITE}-{RESET}" * 50)
                select_difficulty = input(f"{BOLD}{WHITE}Choose difficulty{RESET} ({GREEN}Easy{RESET}, {YELLOW}Medium{RESET}, {RED}Hard{RESET}, {PURPLE}Expert{RESET}): ").lower().capitalize() # Difficulty choice
                print(f"{WHITE}-{RESET}" * 50)

                match(select_difficulty):
                    case "Easy":
                        player.update_health(5)
                        bot.update_health(3)
                        game_state.difficulty = select_difficulty
                    case "Medium":
                        player.update_health(5)
                        bot.update_health(5)
                        game_state.difficulty = select_difficulty
                    case "Hard":
                        player.update_health(3)
                        bot.update_health(5)
                        game_state.difficulty = select_difficulty
                    case "Expert":
                        player.update_health(2)
                        bot.update_health(5)
                        game_state.difficulty = select_difficulty
                
        case "Classic":
                while game_state.difficulty == None:
                    print("\n" + f"{WHITE}-{RESET}" * 50)
                    select_difficulty = input(f"{BOLD}{WHITE}Choose difficulty{RESET} ({GREEN}Easy{RESET}, {YELLOW}Medium{RESET}, {RED}Hard{RESET}, {PURPLE}Expert{RESET}): ").lower().capitalize() # Difficulty choice
                    print(f"{WHITE}-{RESET}" * 50)
                    
                    match(select_difficulty):
                        case "Easy":
                            player.update_health(10)
                            bot.update_health(6)
                            game_state.difficulty = select_difficulty
                        case "Medium":
                            player.update_health(10)
                            bot.update_health(10)
                            game_state.difficulty = select_difficulty
                        case "Hard":
                            player.update_health(6)
                            bot.update_health(10)
                            game_state.difficulty = select_difficulty
                        case "Expert":
                            player.update_health(5)
                            bot.update_health(10)
                            game_state.difficulty = select_difficulty
        case "Admin":
            game_state.difficulty = "Admin"
        
def system_difficulty_influence():
    """Changes the spawn chance of bullets, item probability and items given"""

    match(game_state.gamemode): 

        case "Classic":

            change_bullet_probability = [0] * len(game_state.bullet_probability)
            change_item_probability = [0] * len(game_state.item_probability)

            match(game_state.difficulty.lower()):
                case "easy":
                    change_bullet_probability = [-10, 10, 0]
                    change_item_probability = [-20, -9, 9, 10, 10]
                    game_state.item_give_player_amount = [4, 9]
                    game_state.item_give_bot_amount = [1, 2]
                case "medium":
                    change_bullet_probability = [0, 0, 0]
                    change_item_probability = [0, 0, 0, 0, 0]
                case "hard":
                    change_bullet_probability = [5, -5, 0]
                    change_item_probability = [5, 3, -5, -2, -1]
                    game_state.item_give_player_amount = [1, 7]
                    game_state.item_give_bot_amount = [2, 6]
                    game_state.mag_max_size = [5, 10]
                case "expert":
                    change_bullet_probability = [5, -10, 5]
                    change_item_probability = [12, 6, -7, -3, -2]
                    game_state.item_give_player_amount = [1, 5]
                    game_state.item_give_bot_amount = [3, 7]
                    game_state.mag_max_size = [5, 12]
                    

            for index, value in enumerate(game_state.bullet_probability):
                game_state.bullet_probability[index] = value + change_bullet_probability[index]
    
            for index, value in enumerate(game_state.item_probability):
                game_state.item_probability[index] = value + change_item_probability[index]
    
        case "Admin":
            player.update_health(AdminSettings().player_health)
            bot.update_health(AdminSettings().bot_health)
            game_state.apply_admin()

def system_generate_magazine():
    """Creates an array of bullet types in random size and order"""

    amount_to_generate = random.randint(game_state.mag_max_size[0], game_state.mag_max_size[1])
    bullet_types = ["live", "blank", "special"]
    while True:
        selected_bullet = ""
        one_bullet_type = False
        generated = 0
        game_state.mag.clear()

        while generated < amount_to_generate:

            if 100 in game_state.bullet_probability:
                for i in range(len(game_state.bullet_probability)):
                    if game_state.bullet_probability[i] == 100:
                        selected_bullet = bullet_types[i]
                        one_bullet_type = True
            else:
                selected_bullet = random.choices(bullet_types, weights=game_state.bullet_probability, k=1)[0]

            game_state.mag.append(selected_bullet)
            generated += 1
        
        if "live" in game_state.mag and "blank" in game_state.mag:
            return
        elif one_bullet_type == True:
            return

def system_give_items(target: str, custom_amount: int):
    """Gives items to the player and bot."""

    amount_to_give = 0

    if target == "player":
        time.sleep(1.5)
        print("\n\n" + f"{WHITE}-{RESET}" * 50)
        print(f"🎁  {BOLD}{WHITE}ITEMS{RESET}  🎁".center(60))
        print(f"{WHITE}You received{RESET}:")

        amount_to_give = random.randint(game_state.item_give_player_amount[0], game_state.item_give_player_amount[1])
    else:
        amount_to_give = random.randint(game_state.item_give_bot_amount[0], game_state.item_give_bot_amount[1])

    if custom_amount > 0:
        amount_to_give = custom_amount  

    new_items = [0] * len(items)

    # List of items grouped by tiers
    items_sorted = {1: [], 2: [], 3: [], 4: [], 5: []}
    # Organize items by tier
    for item in items:
        items_sorted[item["tier"]].append(item)

    while amount_to_give > 0:

        tier_to_give = random.choices([1, 2, 3, 4, 5], weights=game_state.item_probability, k=1)[0]

        if items_sorted[tier_to_give]:
            what_to_give = random.choice(items_sorted[tier_to_give])

            if what_to_give["id"] not in game_state.item_ban_list:

                if target == "player":
                    player.inventory[what_to_give["id"]] += 1
                else:
                    bot.inventory[what_to_give["id"]] += 1

                new_items[what_to_give["id"]] += 1
                amount_to_give -= 1

    if target == "player":

        for i, count in enumerate(new_items):
            if count != 0:
                COLOUR = TIER_COLOURS[items[i]["tier"]]
                print(f"📦 {WHITE}{count}x{RESET} {COLOUR}{items[i]["name"]}{RESET}!")
        if custom_amount == 0:
            print(f"{WHITE}-{RESET}" * 50)

def system_binomial_probability(k: int, n: int, p: float):
    """K = Total Live bullets tracked in history, N = Total number of shots tracked in history, P = Current probability of a bullet being Live """
    """Calculates probability of exactly (K+1) = (N+1)."""
    if k > n:
        return 0
    
    binomial_coefficient = math.factorial(n) // (math.factorial(k) * math.factorial(n - k))
    return binomial_coefficient * (p ** k) * ((1 - p) ** (n - k))

def system_binomial_cumulative(k: int, n: int, p: float):
    """K = Total Live bullets tracked in history, N = Total number of shots tracked in history, P = Current probability of a bullet being Live"""
    """Calculates the probability of (K+1) > K in N + 1 shots."""
    cumulative_prob = sum(system_binomial_probability(i, n, p) for i in range(k + 1))
    return cumulative_prob

def bot_evaluate_confidence(event: str):
    """A value which is changed through actions throughout the round."""    

    match(event.lower()):
        case "hit_player" | "blank_self":
            game_state.bot_confidence += 0.15
        case "blank_player":
            game_state.bot_confidence -= 0.1
        case "hit_self" | "heal_player":
            game_state.bot_confidence -= 0.2
        case "power_player" | "heal_self":
            game_state.bot_confidence += 0.2
        case "power_self":
            game_state.bot_confidence -= 0.3
        case "new_round":
            game_state.bot_confidence += 0.1

    if player.health <= 2:
        game_state.bot_confidence += 0.05

    if bot.health <= 2:
        game_state.bot_confidence -= 0.05

    game_state.bot_confidence = max(0.0, min(game_state.bot_confidence, 1.0))

def bot_evaluate_risk():
    """Calculates the risk of the next bullet being a live."""

    blank_left = game_state.mag.count("blank")
    live_left = game_state.mag.count("live")
    special_left = game_state.mag.count("special")
    
    total_bullets = len(game_state.mag)

    # If only 1 type exist within mag
    if blank_left == total_bullets:
        game_state.risk_threshold = 0.0
        return
    elif live_left == total_bullets:
        game_state.risk_threshold = 1.0
        return
    elif special_left == total_bullets:
        game_state.risk_threshold = 0.7
        return 

    history_track_amount = min(3, len(game_state.mag_shot_history))
    history_track_live = game_state.mag_shot_history[:history_track_amount].count("live")

    if history_track_live == history_track_amount:
        game_state.risk_threshold = system_binomial_probability(history_track_amount + 1, history_track_live + 1, live_left / total_bullets)
    else:
        game_state.risk_threshold = 1 - system_binomial_cumulative(history_track_live, history_track_amount + 1, live_left / total_bullets)
    
    game_state.risk_threshold = max(0.0, min(game_state.risk_threshold, 1.0))

def bot_evaluate_playstyle():
    """Determines the bot's play style based on the risk threshold and confidence."""

    # Aggressive 
    if 0.7 <= game_state.risk_threshold and 0.8 <= game_state.bot_confidence:
        return "Very Aggressive"  
    elif 0.7 <= game_state.risk_threshold and 0.5 <= game_state.bot_confidence:
        return "Aggressive"  

    # Neutral 
    elif 0.4 <= game_state.risk_threshold < 0.7 and 0.5 <= game_state.bot_confidence:
        return "Neutral" 
    
    # Cautious
    elif game_state.risk_threshold <= 0.3 and game_state.bot_confidence <= 0.2:
        return "Very Cautious"  
    elif 0.3 <= game_state.risk_threshold < 0.7 and game_state.bot_confidence < 0.5:
        return "Cautious" 

def system_use_item(who: str, item_id: int):

    try:
        if who == "player" and player.inventory[item_id] > 0:
            match(item_id):
                case 0: # Bandage
                    print(f"{TIER_COLOURS[1]}Bandage{RESET} used: {WHITE}+1{RESET} ❤️  {RED}health{RESET}.")
                    player.update_health(1)


                case 1: # Phone
                    if len(game_state.mag) < 2:
                        return print(f"{YELLOW}⚠️  Invalid: You already know what the bullet type is!{RESET}")
                    else:
                        target = random.randint(1, len(game_state.mag) - 1)
                        print(f"The bullet at position {WHITE}{target + 1}{RESET} is a {WHITE}{game_state.mag[target].upper()}{RESET}!")

                case 2: # Magnifying Glass
                    print(f"The {WHITE}current bullet{RESET} is a {WHITE}{game_state.mag[0].upper()}{RESET}!")

                case 3: # Money
                    print(f"The {WHITE}current bullet{RESET} is {WHITE}ejected{RESET} from the magazine!")
                    game_state.mag.pop(0)  # Remove first bullet

                case 4: # Uno Reverse Card
                    if game_state.mag[0] == "live" or game_state.mag[0] == "special":
                        game_state.mag[0] = "blank"
                    else:
                        game_state.mag[0] = "live"
                    print(f"The current bullet's type has been inverted!")
                
                case 7: # Kevlar Vest 
                    if player.active_items[item_id] == True:
                        return print(f"{YELLOW}⚠️ Invalid{RESET}: {TIER_COLOURS[2]}Kevlar Vest{RESET} is already active!")
                    else:
                        print(f"{TIER_COLOURS[2]}Kevlar Vest{RESET} is now {WHITE}active{RESET}!")
                        player.update_active_items(item_id, True)

                case 11: # Medkit 
                    print(f"{TIER_COLOURS[3]}Medkit{RESET} used: {WHITE}+2{RESET} ❤️  {RED}health{RESET}. You've also recovered from any active illnesses!")
                    player.update_health(2)
                
                case 12: # X-ray Goggles
                    if len(game_state.mag) < 3:
                        return print(f"{YELLOW}⚠️  You need at least 3 bullets in the magazine to use this!{RESET}")
                    else:
                        chosen_positions = random.sample(range(len(game_state.mag)), 3)
                        print(f"{TIER_COLOURS[3]}X-ray Goggles{RESET} used:")
                        for position in chosen_positions:
                            print(f"{WHITE}Bullet at position {position + 1}{RESET}: {WHITE}{game_state.mag[position].upper()}{RESET}")
                
                case 13: # Small Crystal Ball
                    target_type = input(f"{WHITE}Which bullet type do you want to search for? ({RED}Live{RESET}, {WHITE}Blank{RESET}, {PURPLE}Special{RESET}): {RESET}").lower()
                    if target_type in ["live", "blank", "special"]:
                        if target_type in game_state.mag:
                            position = game_state.mag.index(target_type) + 1
                            print(f"🔮 The {TIER_COLOURS[4]}Small Crystal Ball{RESET} glows... The next {WHITE}{target_type.upper()}{RESET} bullet is at position {WHITE}{position}{RESET}!")
                        else:
                            return print(f"⚠️  {WHITE}{target_type.upper()}{RESET} {YELLOW}is not in the magazine!{RESET}")
                    else:
                        return print(f"{YELLOW}⚠️  Invalid bullet type!{RESET}")

                case 15: # Suspicious Substance
                    probability = random.choice("positive", "negative")
                    print(f"You take the {TIER_COLOURS[3]}Suspicious Substance{RESET}...")
                    time.sleep(0.5)
                    if probability == "positive":
                        print(f"You feel {WHITE}immense power{RESET} surging through your body! {WHITE}+3{RESET} ❤️  {RED}health{RESET}")
                        player.update_health(3)
                    else:
                        print(f"You feel {WHITE}weakened{RESET} and {WHITE}in pain{RESET}! {WHITE}-3{RESET} ❤️  {RED}health{RESET}")
                        player.update_health(-3)
                
                case 21:  # Mystery Box
                    print(f"You {WHITE}opened{RESET} the {TIER_COLOURS[5]}Mystery Box{RESET}. . .")
                    system_give_items("player", 5)  # Gives 5 random items
                    print(f"{WHITE}-{RESET}" * 50)
            
            player.inventory[item_id] -= 1
        else:
            return print(f"{YELLOW}⚠️  You don't have this item!{RESET}")
    except:
        return print(f"{YELLOW}⚠️  Invalid item ID!{RESET}")

def system_shoot_target(target: str):

    responses = [
    # Player shot by live
    "💥 BOOM! You shot yourself with a LIVE bullet! 😵", # 0 
    "💥 Bang! You got hit by a LIVE bullet. Ouch! 🩸", # 1
    # Bot shot by live
    "🎯 Nice shot! The opponent took a LIVE bullet!", # 2
    "💥 BOOM! Your opponent shot themselves with a LIVE bullet. Lucky!", # 3
    # Player shot by blank
    "🔄 CLICK! It was a BLANK. Lucky!", # 4
    "🔄 CLICK! Your opponent tried to shoot you, good thing it was a BLANK! Phew!", # 5
    # Bot shot by blank
    "❌ Missed! It was a BLANK.", # 6
    "🔄 CLICK! Your opponent pulled the trigger on themselves, it was a BLANK!", # 7
    # Player shot by special (damage)
    "⚡ ZAP! That was a POWER bullet, and it hit you hard! You lost extra health! ⚡",  # 8
    "⚡ That was a POWER bullet! It struck you with extra force. Ouch! 😵",  # 9
    # Bot shot by special (damage)
    "🔥 Direct hit! That was a POWER bullet, and your opponent took extra damage! 🔥",  # 10
    "💥 BOOM! Your opponent just shot themselves with a POWER bullet! That's gotta hurt!",  # 11
    # Player shot by special (heal)
    "✨ What?! That was a HEALING bullet, and it healed you! You feel stronger! 💪",  # 12
    "🍀 The opponent shot you, but it was a HEALING bullet! You gained health!",  # 13
    # Bot shot by special (heal)
    "🛡️  Oh no! That was a HEALING bullet, and it actually healed your opponent! 😱",  # 14
    "😱 Unbelievable! The opponent shot themselves with a HEALING bullet and it gave them health back!",  # 15
    ]

    time.sleep(0.5)
    print(f"{WHITE}-{RESET}" * 50)
    match(game_state.mag[0]):
        case "live":
            if target == "player":
                if player.active_items[7] == True:
                    print(f"The {TIER_COLOURS[2]}Kevlar Vest{RESET} {WHITE}protected{RESET} you from taking {WHITE}1{RESET} {RED}damage{RESET}!")
                    print(f"{WHITE}-{RESET}" * 50 + "\n")
                    player.update_active_items(7, False)
                else:
                    player.update_health(-1)
                    print(f"{responses[0 if permissions.is_player_turn else 1]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                
                if permissions.is_player_turn == False:
                    bot_evaluate_confidence("hit_player")
            else:
                bot.update_health(-1)
                print(f"{responses[2 if permissions.is_player_turn else 3]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                
                if permissions.is_player_turn == False:
                    bot_evaluate_confidence("hit_self")

            permissions.is_player_turn = not permissions.is_player_turn
            game_state.turn += 1
        case "blank":
            if target == "player":
                print(f"{responses[4 if permissions.is_player_turn else 5]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                if permissions.is_player_turn == False:
                    bot_evaluate_confidence("blank_player")
                    game_state.turn += 1
                    
                permissions.is_player_turn = True
            else:
                print(f"{responses[6 if permissions.is_player_turn else 7]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                if permissions.is_player_turn == True:
                    game_state.turn += 1

                if permissions.is_player_turn == False:
                    bot_evaluate_confidence("blank_self")

                permissions.is_player_turn = False 
        case "special":
            if random.randint(1, 2) == 1:
                if target == "player":
                    if player.active_items[7] == True:
                        print(f"The {TIER_COLOURS[2]}Kevlar Vest{RESET} {WHITE}protected{RESET} you from taking {WHITE}1{RESET} {RED}damage{RESET}!")
                        print(f"{WHITE}-{RESET}" * 50 + "\n")
                        time.sleep(0.5)
                        print(f"However the POWER bullet still dealt {WHITE}1{RESET} {RED}damage{RESET} to you!")
                        print(f"{WHITE}-{RESET}" * 50 + "\n")

                        player.update_health(-1)
                        player.update_active_items(7, False)
                    else: 
                        player.update_health(-2)
                        print(f"{responses[8 if permissions.is_player_turn else 9]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                    
                    if permissions.is_player_turn == False:
                        bot_evaluate_confidence("power_player")
                else:
                    bot.update_health(-2)
                    print(f"{responses[10 if permissions.is_player_turn else 11]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                    
                    if permissions.is_player_turn == False:
                        bot_evaluate_confidence("power_self")
                permissions.is_player_turn = not permissions.is_player_turn
            else:
                if target == "player":
                    player.update_health(2)
                    print(f"{responses[12 if permissions.is_player_turn else 13]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                    if permissions.is_player_turn == True:
                        permissions.is_player_turn = False
                    else:
                        bot_evaluate_confidence("heal_player")
                        permissions.is_player_turn = True
                else:
                    bot.update_health(2)
                    print(f"{responses[14 if permissions.is_player_turn else 15]}\n" + f"{WHITE}-{RESET}" * 50 + "\n")
                    if permissions.is_player_turn == True:
                        permissions.is_player_turn = False
                    else:
                        bot_evaluate_confidence("heal_self")
                        permissions.is_player_turn = True
            game_state.turn += 1
    game_state.mag.remove(game_state.mag[0])
    time.sleep(1)

def player_decision():
    print(f"{WHITE}🔫 YOUR TURN!{RESET}")
    print(f"{WHITE}-{RESET}" * 50)
    while True:
        try:
            whatToDo = int(input(f"{WHITE}What would you like to do? {YELLOW}Shoot (1){RESET}{WHITE} | {RESET}{YELLOW}Use Item (2): {RESET}"))
            match(whatToDo):
                case 1: # Shoot
                    decision = int(input(f"{WHITE}Select who to shoot! {YELLOW}Shoot yourself (1){RESET}{WHITE} | {RESET}{YELLOW}Shoot opponent (2): {RESET}"))
                    match(decision):
                        case 1: # Player shoots themselves
                            system_shoot_target("player")
                            break
                        case 2: # Player shoots opponent
                            system_shoot_target("bot")
                            break
                        case _:
                            print(f"{YELLOW}⚠️  Invalid choice! Enter 1 or 2.{RESET}")
                case 2: # Use item
                    if game_state.gamemode.lower() == "quickplay":
                        print(f"{YELLOW}⚠️  Invalid choice! Items are not in Classic.{RESET}")
                    else:
                        time.sleep(0.5)
                        print(f"{WHITE}-{RESET}" * 50)
                        print(f"{BOLD}{WHITE}🎒 Your Inventory{RESET}".center(60))
                        for index, item_info in enumerate(items):
                            if player.inventory[index] > 0:
                                COLOUR = TIER_COLOURS[item_info["tier"]]
                                print(f"📦 [{YELLOW}ID: {index}{RESET}] {WHITE}{player.inventory[index]}x{RESET} {COLOUR}{item_info["name"]}{RESET} \n        - ({item_info["description"]})")
                        print(f"{WHITE}-{RESET}" * 50)
                        try:
                            grab_id = input(f"{YELLOW}Enter the ID{RESET}{WHITE} of the item you want to use{RESET} ({YELLOW}Quit{RESET}{WHITE} to return): {RESET}")
                            if grab_id.lower() == "quit":
                                break
                            else:
                                print(f"{WHITE}-{RESET}" * 50)
                                system_use_item("player", int(grab_id))
                                print(f"{WHITE}-{RESET}" * 50)
                                break 
                        except: 
                            print(f"{YELLOW}⚠️  Invalid item ID!{RESET}")                          
                        break
                case _: 
                    print(f"{YELLOW}⚠️  Invalid choice! Enter 1 or 2.{RESET}")
        except ValueError:
            print(f"{YELLOW}⚠️  Invalid choice! Enter 1 or 2.{RESET}")
      
def bot_decision():
    time.sleep(0.75)
    bot_thoughts = [
        f"🤖 {WHITE}Analysing... {RESET}",
        f"🤖 {WHITE}Thinking... {RESET}",
        f"🤖 {WHITE}Processing... {RESET}",
        f"🤖 {WHITE}Evaluating... {RESET}",
        f"🤖 {WHITE}Assessing... {RESET}",
        f"🤖 {WHITE}Calculating... {RESET}",
        f"🤖 {WHITE}Considering... {RESET}",
        f"🤖 {WHITE}Strategising... {RESET}",
    ]
    bot_responses = [
        # Only Live Bullets left # 0
        [
            f"(Only {RED}LIVE{RESET} bullets left... Time to {YELLOW}ATTACK{RESET})",
            f"(There's only {RESET}LIVE{RESET} bullets inside the magazine, {YELLOW}ATTACK{RESET}!)",
            f"(Risk level is 100%, I'll seize this opportunity to {YELLOW}ATTACK{RESET}!)",
        ],
        # Only Blank Bullets Left # 1 
        [
            f"(Only {WHITE}BLANK{RESET} bullets left... I'll shoot {WHITE}MYSELF{RESET})",
            f"(Nothing but {WHITE}BLANK{RESET} bullets! I know what to do.)",
            f"(No more {RED}LIVE{RESET} bullets in the magazine... I shall shoot {WHITE}MYSELF{RESET})",
            f"(I'll shoot {WHITE}MYSELF{RESET} as there's only {WHITE}BLANK{RESET} bullets left!)",
        ],
        # Only Special Bullets Left # 2
        [
            f"(Only {PURPLE}SPECIAL{RESET} bullets left... I'm not sure what to do.)",
            f"(Uncertain... Many {PURPLE}SPECIAL{RESET} bullets detected!)",
        ],
        # High Risk Shooting Player # 3
        [
            f"(The risk is {RED}HIGH{RESET}... I'll {YELLOW}ATTACK{RESET}!)", 
            f"({RED}HIGH{RESET} risk detected, time to {YELLOW}ATTACK{RESET}!)", 
            f"(I reckon {YELLOW}ATTACK{RESET} is the best option here, take this!)", 
            f"(Odds favour me... {YELLOW}ATTACK{RESET} time!)", 
            f"(Time to make my move, {YELLOW}ATTACK{RESET} is the only choice!)", 
        ],
        # Moderate Risk Shooting Player # 4
        [
            f"(Risk level is {YELLOW}MODERATE{RESET}... I think I'll {YELLOW}ATTACK{RESET}.)",
            f"(The chances of a {RED}LIVE{RESET} bullet are reasonable... {YELLOW}ATTACK{RESET}!)",
            f"(I'll take the gamble... {YELLOW}ATTACK{RESET}!)",
            f"(Risky, but worth it... Time to {YELLOW}ATTACK{RESET}!)",
        ],
        # Low Risk Shooting PLayer # 5
        [
            f"(Risk level is {GREEN}LOW{RESET}, but there's still a chance... I'll {YELLOW}ATTACK{RESET}.)",
            f"({GREEN}LOW{RESET} risk detected, but I should still {YELLOW}ATTACK{RESET}.)",
            f"(The odds of a {RED}LIVE{RESET} bullet are low, but I'll take the shot anyway.)",
            f"(Seems safe enough... I'll {YELLOW}ATTACK{RESET} anyway!)",
            f"({GREEN}LOW{RESET} risk detected, I should make the logical move... just kidding, {YELLOW}ATTACK{RESET}!)",
        ],
        # High Risk Shooting Self # 6
        [
            f"(The odds are against me... but maybe I'll get lucky? Shooting {WHITE}MYSELF{RESET}!)",
            f"(It's a gamble... and I love a good gamble! Shooting {WHITE}MYSELF{RESET}!)",
            f"({RED}HIGH{RESET} risk detected! But maybe luck is on my side... Shooting {WHITE}MYSELF{RESET}!)",
            f"(Risk is {RED}HIGH{RESET}...This could be the worst decision ever... or the best! Shooting {WHITE}MYSELF{RESET}!)",
            f"(I trust in fate! May the odds be in my favor... Shooting {WHITE}MYSELF{RESET}!)",
            f"(I have no calculations for luck... but here goes nothing! Shooting {WHITE}MYSELF{RESET}!)",
            f"(Odds are against me... But I believe this is a {WHITE}BLANK{RESET}! Shooting {WHITE}MYSELF{RESET}!)",
            f"(Despite a {RED}HIGH{RESET} risk, I shall be unpredictable! So I'll shoot {WHITE}MYSELF{RESET}!)",
            f"(If luck is real, now's the time to believe in it! Shooting {WHITE}MYSELF{RESET}!)",
            f"(Do bots have luck? Only one way to find out... Shooting {WHITE}MYSELF{RESET}!)",
        ],
        # Moderate Risk Shooting Self # 7 
        [
            f"(Risk level is {YELLOW}MODERATE{RESET}, but shooting {WHITE}MYSELF{RESET} could work.)",
            f"(It's a {YELLOW}MODERATE{RESET} risk, but I trust my luck... Shooting {WHITE}MYSELF{RESET}.)",
            f"(I'll take my chances... Shooting {WHITE}MYSELF{RESET}.)",
        ],
        # Low Risk Shooting Self # 8
        [
            f"(Risk level is {GREEN}LOW{RESET}, I'll shoot {WHITE}MYSELF{RESET})", 
            f"({GREEN}LOW{RESET} risk detected, it must be a {WHITE}BLANK{RESET}!)",
            f"(The likelihood of a {RED}LIVE{RESET} is low... Shooting {WHITE}MYSELF{RESET})",
            f"(Odds are in my favour... Shooting {WHITE}MYSELF{RESET}.)",
            f"(Almost certain safety... Shooting {WHITE}MYSELF{RESET}!)",
        ],
    ]
    print(f"{WHITE}🤖 OPPONENT'S TURN!{RESET}")
    print(f"{WHITE}-{RESET}" * 50)
    time.sleep(0.75)

    bot_evaluate_risk()

    print(random.choice(bot_thoughts))
    time.sleep(0.5)
    # When risk = 1 (All bullets remaining are live)
    if game_state.risk_threshold == 1.0:
        print(random.choice(bot_responses[0]))
        
        return system_shoot_target("player")

    # When risk = 0 (All bullets remaining are blank)
    if game_state.risk_threshold == 0.0:
        print(random.choice(bot_responses[1]))

        return system_shoot_target("bot")

    # When All bullets remaining are special
    if game_state.risk_threshold == 0.7 and game_state.mag.count("special") == len(game_state.mag):
        print(random.choice(bot_responses[2]))
        decision = random.choice(["bot", "player", "player"]) # Slight bias towards attacking

        return system_shoot_target(decision)

    # Determine playstyle
    match(bot_evaluate_playstyle()):

        # Decision based on play style
        case "Very Aggressive":
            print(f"{CYAN}Playstyle: VERY AGGRESSIVE (not yet implemented){RESET}")
        
        case "Aggressive":
            print(f"{CYAN}Playstyle: AGGRESSIVE (not yet implemented){RESET}")
        
        case "Neutral":
            print(f"{CYAN}Playstyle: NEUTRAL (not yet implemented){RESET}")
        
        case "Very Cautious":
            print(f"{CYAN}Playstyle: VERY CAUTIOUS (not yet implemented){RESET}")
        
        case "Cautious":
            print(f"{CYAN}Playstyle: CAUTIOUS (not yet implemented){RESET}")

    # If no playstyle is defined

    if 0.7 <= game_state.risk_threshold < 1: # High risk
        if random.random() < 0.9:
            print(random.choice(bot_responses[3]))
            time.sleep(0.5)
            return system_shoot_target("player")
        else:
            # Taking the risk anyway
            print(random.choice(bot_responses[6]))
            time.sleep(0.5)
            print(f"{WHITE}-{RESET}" * 50)
            return system_shoot_target("bot")
    if 0.4 <= game_state.risk_threshold < 0.7: # Moderate risk  
        if random.random() < 0.65:
            print(random.choice(bot_responses[4]))
            time.sleep(0.5)
            return system_shoot_target("player")
        else:
            print(random.choice(bot_responses[7]))
            time.sleep(0.5)
            return system_shoot_target("bot")
    if 0 < game_state.risk_threshold < 0.4: # Low risk
        if random.random() < 0.2:
            # Believes it will be a live
            print(random.choice(bot_responses[5]))
            time.sleep(0.5)
            return system_shoot_target("player")
        else:
            print(random.choice(bot_responses[8]))
            time.sleep(0.5)
            return system_shoot_target("bot")
    

def system_game_start():
    introduction()
    input_start()
    input_gamemode()
    input_difficulty()
    system_difficulty_influence()

def system_game_logic():

    print(f"{BOLD}{WHITE}STARTING GAME. . .{RESET}")
    time.sleep(1)
    print("\n\n\n" + f"{WHITE}={RESET}" * 50)
    print(f"🎯 {BOLD}{WHITE}GAME SETTINGS{RESET} 🎯".center(60))
    print(f"{WHITE}Gamemode{RESET}: {game_state.gamemode}")
    print(f"{WHITE}Difficulty{RESET}: {game_state.difficulty}")
    print(f"{WHITE}Player:{RESET} {RED}{player.health}{RESET} ❤️  {WHITE}| Bot:{RESET} {RED}{bot.health}{RESET} ❤️")
    print(f"{WHITE}={RESET}" * 50)

    while player.health > 0 and bot.health > 0:
        
        time.sleep(1.5)
        game_state.round += 1
        bot_evaluate_confidence("new_round")
        game_state.turn = 1
        
        print("\n\n\n\n" + f"{WHITE}={RESET}" * 50)
        print(f"{BOLD}{WHITE}🎲 ROUND {game_state.round} 🎲{RESET}".center(60))
        print(f"{WHITE}={RESET}" * 50)
        
        system_generate_magazine()
        
        system_give_items("player", 0)
        system_give_items("bot", 0)

        time.sleep(1.5)
        while len(game_state.mag) > 0:
            
            bullet_info = [game_state.mag.count("live"), game_state.mag.count("blank"), game_state.mag.count("special")]
            print("\n\n" + f"{WHITE}-{RESET}" * 50)
            print(f"🕹️  {BOLD}{WHITE}TURN {game_state.turn}{RESET}".center(60))
            print(f"😐 {WHITE}Player:{RESET} {RED}{player.health}{RESET} ❤️  {WHITE}| 🤖 Bot:{RESET} {RED}{bot.health}{RESET} ❤️".center(75))
            print(f"\n🔴 {WHITE}{bullet_info[0]}{RESET} LIVE(S) left\n⚪ {WHITE}{bullet_info[1]}{RESET} BLANK(S) left\n🟣 {WHITE}{bullet_info[2]}{RESET} SPECIAL(S) left")
            print(f"{WHITE}-{RESET}" * 50)
            
            time.sleep(1)

            if permissions.is_player_turn:
                player_decision()
            else:
                bot_decision() 
            time.sleep(1)

            # End game if either side is below 0 HP
            if player.health <= 0:
                print("\n" + f"{WHITE}-{RESET}" * 50 + f"\n💀 {BOLD}{WHITE}GAME OVER!{RESET} {BOLD}{RED}You lost!{RESET} 💀\n" + f"{WHITE}-{RESET}" * 50)
                return
            elif bot.health <= 0:
                print("\n" + f"{WHITE}-{RESET}" * 50 + f"\n🎉 {BOLD}{WHITE}CONGRATULATIONS!{RESET} {BOLD}{YELLOW}You won!{RESET} 🎉\n" + f"{WHITE}-{RESET}" * 50)
                return
        time.sleep(0.5)
        print("\n\n")
        print(f"{WHITE}-{RESET}" * 50)
        print(f"{BOLD}{WHITE}Magazine empty! Starting new round. . .{RESET}")
        print(f"{WHITE}-{RESET}" * 50 + "\n")
    

def system_debug():

    print(f"Bullet Probability: {game_state.bullet_probability}")
    print(f"Item Probability: {game_state.item_probability}")
    print(f"Item Spawn Amount: {game_state.item_give_player_amount}")
    print(f"Bot Health: {bot.health}")
    print(f"Player Health: {player.health}")
    print(f"Game Mode: {game_state.gamemode}")
    print(f"Difficulty: {game_state.difficulty}")

def system_reset_variables():

    player.reset()
    bot.reset()
    game_state.reset()
    game_stats.reset()
    permissions.reset()

def system_initiate():
    
    system_game_start()
    system_game_logic()

    #system_debug()

    system_reset_variables()
# ====================================================================================================


# [Game manager]
# ====================================================================================================
while True:
    system_initiate()
    
    print("\n\n")
    print(f"{WHITE}-{RESET}" * 50)
    if len(input(f"{WHITE}PLAY AGAIN?{RESET} ({YELLOW}Type any key to continue{RESET}): ")) >= 0:
        time.sleep(0.25)
        print(f"{WHITE}RESETTING. . .")
        time.sleep(0.5)
        print("\n" * 5)
    
        system_reset_variables()
    else: 
        break
# ====================================================================================================

# [Patch notes]
# ====================================================================================================
''' TO DO LIST: '''

# - Iron Shield (Shield you from 1 instance of damage and ill-effects)
# - Slot Machine (Pay with 1 health, 60% of receiving 3 stacks of Money)
# - Petrol (Pours petrol to coat the next bullet, the next bullet will light the opponent on fire for 2 turns, however there is 60% chance of the bullet exploding, wasting the turn)
# - Faulty Defibrillator (If player receives fatal shot within the next 2 turns, keeps the player alive with 1 hp)
# - Large Crystal Ball (Select any type of bullet to find and returns the position of the first target type found)
# - Fire Extinguisher (Removes the burn affect)
# - Herbs (Removes any illness)
# - Four-Leaf Clover (Permanently increase luck by 2%)
# - Book of Fortune (Reading from it grants and temporary increase in luck by 20% for the next 3 turns)
# - Wine (Ignores illness effects for 2 turn)
# - Ciggarette (Ignores illness effects for 1 turn)
# - Magic potion (Regenerate the user's health by 1 for the next 5 turn)


''' PAST PATCHES: '''

# V1.5 - Overall Update
    # - GAMEPLAY
        # - New Item: Kevlar Vest [Tier 2] (Protects the user from 1 point of damage. Breaks after one use.)
        # - New Item: X-ray Goggles [Tier 3] (Provides information on 3 random bullets in the magazine.)
        # - New Item: Mystery Box [Tier 5] (Receive 5 random items.)
        # - New Item: Suspicious Substance [Tier 3] (Has an equal chance of a positive or negative effect when used.)
        # - New Item: Small Crystal Ball [Tier 3] (Reveals the position of the first bullet of a chosen type in the magazine.)
    # - BOT UPDATE
        # - 
    # - OTHER
        # - Fixed Suspicious Substance's quantity not being reduced after usage
        # - Fixed Items spawning inside quickplay
        # - Changed spawn chance of different tiers of items [45, 29, 18, 9, 4]
        # - Changed Expert difficulty on Classic mode to give the bot 15 health instead of 10

# V1.4 - Gameplay update 
    # - ITEMS
        # - New gameplay feature (items can be used in rounds to gain an advantage)
        # - New item: Bandage (heals 1 health)
        # - New item: Medkit (heals 2 health and removes any illness)
        # - New item: Phone (reveals the type of a random bullet in the mag except the current)
        # - New item: Magnifying Glass (reveals the current bullet type)
        # - New item: Money (can be used to bribe the system, eject the current bullet, retain turn).
        # - New item: Uno Reverse Card (Inverts the bullet type to blank or live)
        # - Player will receive a random amount of items at the beginning of each round
        # - Unused items will carry on to the next round
    # - GAMEMODES
        # Quickplay: Fast paced rounds with no items and less starting health
        # Classic: Standard game with items being awarded when a new round starts, more bullets per round and higher starting health
    # - OTHER
        # - Fixed minor UI issues
        # - Added colours to text to brighten up the game
        # - Added option for player to use item when making decisions
        # - Psst~ Secret admin gamemode... (who knows what settings you get XD)

# V1.3 - Gameplay and bot logic update
    # - Bot now makes smarter decisions based on remaining bullets.
    # - Bot will always shoot itself if all remaining bullets are BLANK.
    # - Bot will always shoot the player if all remaining bullets are LIVE.
    # - Bot will adapt its strategy when SPECIAL bullets are the majority.
    # - Magazines are now guaranteed to have both BLANK and LIVE bullets.
    # - New Expert Difficulty: Player (3 HP) vs Opponent (8 HP).
    # - New SPECIAL Bullet: Effects are unknown until fired (heals +2 or deals -2 damage).
    # - General balancing & improvements.

# V1.2.1 - Bug fixes
    # - Fixed message not sending celebrating or informing the player if they've won or lost
    # - Fixed game randomly ending
    # - Fixed turn number not resetting and continuing into the next game

# V1.2 - Background update
    # - Player can replay the game without having to restart the program
    # - Reorganised the code
    # - Removed unnecessary code

# V1.1 - UI update 
# ====================================================================================================